﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("VoxelModelConverter")]
[assembly: InternalsVisibleTo("xTests")]
