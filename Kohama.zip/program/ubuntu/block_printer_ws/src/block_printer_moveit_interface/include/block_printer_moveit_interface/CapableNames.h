#pragma once
#include <string>

namespace block_printer_moveit_interface
{
static const std::string COMMANDS_ACTION = "/block_printer/moveit_interface/commands";
static const std::string GRIPPER_ACTION = "/gripper_action";
} // namespace block_printer_moveit_interface