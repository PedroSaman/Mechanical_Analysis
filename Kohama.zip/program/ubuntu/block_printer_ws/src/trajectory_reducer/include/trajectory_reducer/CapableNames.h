#pragma once
#include <string>

namespace trajectory_reducer
{
    static const std::string REDUCE_TRAJECTORY_SERVICE = "";
}