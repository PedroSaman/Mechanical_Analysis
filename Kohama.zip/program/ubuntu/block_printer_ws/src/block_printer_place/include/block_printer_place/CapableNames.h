#pragma once
#include <string>

namespace block_printer_place
{
static const std::string PLACE_POSE_SERVICE = "/block_printer/get_place_pose";
} // namespace block_printer_model_reader