#pragma once
#include <string>

namespace block_printer_pick
{
static const std::string PICK_POSE_SERVICE = "/block_printer/get_pick_pose";
} // namespace block_printer_pick