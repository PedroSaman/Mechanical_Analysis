# cartesian_robot
simple 4-dof cartesian robot
