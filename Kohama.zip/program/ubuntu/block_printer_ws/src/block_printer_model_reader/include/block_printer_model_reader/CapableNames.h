#pragma once
#include <string>

namespace block_printer_model_reader
{
static const std::string BLOCK_STATE_SERVICE = "/block_printer/get_component_block";
static const std::string COMPONENT_BLOCK_SERVICE = "/block_printer/get_block_state";
} // namespace block_printer_model_reader