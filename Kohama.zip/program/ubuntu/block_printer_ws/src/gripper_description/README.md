# gripper_description
A simple URDF of TAIYO ESG1-FS-2840 gripper.