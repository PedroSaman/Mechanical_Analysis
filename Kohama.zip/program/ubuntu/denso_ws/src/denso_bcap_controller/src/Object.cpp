#include <denso_bcap_controller/Object.h>

using namespace denso_bcap_controller;

Object::Object(RcController &controller) : controller(controller) {}

Object::~Object() {}
