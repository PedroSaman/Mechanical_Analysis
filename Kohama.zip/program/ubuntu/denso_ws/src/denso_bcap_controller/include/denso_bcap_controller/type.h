#pragma once

namespace denso_bcap_controller
{
typedef uint32_t BCapHandle;
}