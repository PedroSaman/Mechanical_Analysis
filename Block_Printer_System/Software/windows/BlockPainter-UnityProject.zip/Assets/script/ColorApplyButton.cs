﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class ColorApplyButton : MonoBehaviour
{
    public ToggleGroup toggleGroup;
    public GameObject blockFactoryAttachedObject;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void onClick()
    {
        //Get the label in activated toggles
        string selectedLabel = toggleGroup.ActiveToggles()
            .First().GetComponentsInChildren<Text>()
            .First(t => t.name == "Label").text;
        var colorData = BlockColor.GetFromName(selectedLabel);
        this.blockFactoryAttachedObject.GetComponent<BlockFactory>().CurrentColorIndex = colorData.Index;
    }

    public void onSaveClick()
    {
        var blockFactory = this.blockFactoryAttachedObject.GetComponent<BlockFactory>();
        blockFactory.WriteColoredKozakiBlockModelFile();
    }
}
