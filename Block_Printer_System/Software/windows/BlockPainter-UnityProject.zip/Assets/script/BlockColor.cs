﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ColorData
{
    public readonly int Index;
    public readonly string Name;
    public readonly Color Color;
    public ColorData(int index, string name, Color color)
    {
        this.Index = index;
        this.Name = name;
        this.Color = color;
    }
}

public static class BlockColor
{
    private static readonly List<ColorData> data;
    static BlockColor()
    {
        data = new List<ColorData>
        {
            new ColorData(0, "White", Color.white),
            new ColorData(1, "Red", Color.red),
            new ColorData(2, "Orange", new Color(0.9f, 0.6f, 0)),
            new ColorData(3, "Yellow", Color.yellow),
            new ColorData(4, "Green", Color.green),
            new ColorData(5, "Blue", Color.blue),
            new ColorData(6, "Black", Color.black),
            new ColorData(7, "Support", new Color(1, 1, 1, 0.2f))
        };
    }
    public static ColorData GetFromIndex(int index)
    {
        return data.First(d => d.Index == index);
    }
    public static ColorData GetFromName(string name)
    {
        return data.First(d => d.Name.ToLower() == name.ToLower());
    }
}
