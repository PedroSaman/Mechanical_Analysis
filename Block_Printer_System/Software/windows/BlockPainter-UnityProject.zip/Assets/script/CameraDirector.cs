﻿using UnityEngine;

public class CameraDirector : MonoBehaviour
{
    public Vector2 translationSpeed;
    public Vector2 rotationSpeed;
    public float zoomSpeed;
    public bool reverse;
    private Vector2 lastMousePosition;
    private Vector2 newAngle = new Vector2(0, 0);
    private Transform initialTransform;

    void Start()
    {
        this.initialTransform = this.transform;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Z) || Input.GetKey(KeyCode.X)) return;
        // 左クリックした時
        if (Input.GetMouseButtonDown(0))
        {
            this.newAngle = this.transform.localEulerAngles;
            this.lastMousePosition = Input.mousePosition;
        }
        // 左クリック中は回転
        else if (Input.GetMouseButton(0))
        {
            this.newAngle.y -= (this.lastMousePosition.x - Input.mousePosition.x) * this.rotationSpeed.y * (reverse ? 1 : -1);
            this.newAngle.x -= (Input.mousePosition.y - this.lastMousePosition.y) * this.rotationSpeed.x * (reverse ? 1 : -1);
            this.transform.localEulerAngles = newAngle;
            this.lastMousePosition = Input.mousePosition;
        }
        //右クリックしたとき
        else if (Input.GetMouseButtonDown(1))
        {
            this.lastMousePosition = Input.mousePosition;
        }
        //右クリック中は平行移動
        else if (Input.GetMouseButton(1))
        {
            var deltaX = Input.mousePosition.x - this.lastMousePosition.x;
            var deltaY = Input.mousePosition.y - this.lastMousePosition.y;
            this.transform.Translate(new Vector3(deltaX * this.translationSpeed.x, deltaY * this.translationSpeed.y), Space.Self);
            this.lastMousePosition = Input.mousePosition;
        }
        //中クリックで初期姿勢へ戻る
        else if (Input.GetMouseButtonDown(2))
        {
            this.transform.position = this.initialTransform.position;
            this.transform.rotation = this.initialTransform.rotation;
        }
        //マウスホイールで前進後退
        this.transform.Translate(new Vector3(0, 0, Input.mouseScrollDelta.y * this.zoomSpeed), Space.Self);
    }
}
