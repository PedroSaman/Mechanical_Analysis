﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using SimpleFileBrowser;

public class BlockFactory : MonoBehaviour
{
    class BlockGameObject
    {
        public GameObject gameObject;
        public Block script;
        public int bottomPosition;
        public bool removed;
    }
    enum BlockOperation
    {
        Colorize,
        Remove,
    }
    class BlockOperationHistory
    {
        public GameObject gameObject;
        public BlockOperation Operation;
        public Block script;
        public ColorData previousColor;
    }
    public UnityEngine.UI.Text blockModelText;
    public int CurrentColorIndex;
    private int activePosition;
    private List<BlockGameObject> blocks;
    private List<BlockOperationHistory> operationHistories;
    // Use this for initialization
    void Start()
    {
        this.blocks = new List<BlockGameObject>();
        this.operationHistories = new List<BlockOperationHistory>();
        this.CurrentColorIndex = 0;
    }

    // Update is called once per frame
    void Update()
    {
        var activeChanged = false;
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            this.activePosition++;
            activeChanged = true;
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            this.activePosition--;
            activeChanged = true;
        }
        //ブロックの表示・非表示切り替え
        if (activeChanged)
        {
            foreach (var block in this.blocks)
            {
                var removeOperation = this.operationHistories
                    .Where(h => h.Operation == BlockOperation.Remove)
                    .LastOrDefault(h => ReferenceEquals(h.gameObject, block.gameObject));
                var hasRemoved = removeOperation != null;
                var active = !hasRemoved && block.script.Z < this.activePosition;
                block.gameObject.SetActive(active);
            }
        }
        //色付け
        if (Input.GetKey(KeyCode.Z) && Input.GetMouseButton(0))
        {
            RaycastHit hit;
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            //マウスクリックした場所からRayを飛ばし、オブジェクトがあればtrue 
            if (Physics.Raycast(ray.origin, ray.direction, out hit, Mathf.Infinity))
            {
                var collisionObject = hit.collider.gameObject;
                if (collisionObject.CompareTag("Block"))
                {
                    var script = collisionObject.GetComponent<Block>();
                    if (script.ColorIndex != this.CurrentColorIndex)
                    {
                        var previousColor = BlockColor.GetFromIndex(script.ColorIndex);
                        var nextColor = BlockColor.GetFromIndex(this.CurrentColorIndex);
                        script.SetColor(nextColor);
                        BlockOperationHistory history = new BlockOperationHistory()
                        {
                            gameObject = collisionObject,
                            script = script,
                            previousColor = previousColor,
                        };
                        this.operationHistories.Add(history);
                    }
                }
            }
        }
        //削除
        if (Input.GetKey(KeyCode.X) && Input.GetMouseButton(0))
        {
            RaycastHit hit;
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            //マウスクリックした場所からRayを飛ばし、オブジェクトがあればtrue 
            if (Physics.Raycast(ray.origin, ray.direction, out hit, Mathf.Infinity))
            {
                var collisionObject = hit.collider.gameObject;
                if (collisionObject.CompareTag("Block"))
                {
                    int? removeBlockIndex = null;
                    for (int i = 0; i < this.blocks.Count; i++)
                    {
                        if (ReferenceEquals(collisionObject, this.blocks[i].gameObject))
                        {
                            removeBlockIndex = i;
                            break;
                        }
                    }
                    if (removeBlockIndex.HasValue)
                    {
                        BlockOperationHistory history = new BlockOperationHistory()
                        {
                            gameObject = collisionObject,
                            Operation = BlockOperation.Remove,
                            script = this.blocks[removeBlockIndex.Value].script,
                            previousColor = BlockColor.GetFromIndex(this.blocks[removeBlockIndex.Value].script.ColorIndex),
                        };
                        this.operationHistories.Add(history);
                        this.blocks[removeBlockIndex.Value].removed = true;
                        collisionObject.SetActive(false);
                    }
                }
            }
        }
        //変更の巻き戻し
        if ((Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
            && Input.GetKeyDown(KeyCode.Z)
            && this.operationHistories.Any())
        {
            var last = this.operationHistories.Last();
            if (last.Operation == BlockOperation.Colorize)
            {
                last.script.SetColor(last.previousColor);
            }
            else if (last.Operation == BlockOperation.Remove)
            {
                last.gameObject.SetActive(true);
                for (int i = 0; i < this.blocks.Count; i++)
                {
                    if (ReferenceEquals(last.gameObject, this.blocks[i].gameObject))
                    {
                        this.blocks[i].removed = false;
                        break;
                    }
                }
            }
            else
            {
                throw new InvalidOperationException("unexpected operation " + last.Operation);
            }
            this.operationHistories.RemoveAt(this.operationHistories.Count - 1);
        }
    }

    public void LoadBlockModelFile()
    {
        FileBrowser.OnSuccess onSuccess = (path) =>
        {
            var beforeBlocks = GameObject.FindGameObjectsWithTag("Block");
            foreach (var beforeBlock in beforeBlocks) Destroy(beforeBlock);
            this.blocks.Clear();
            this.operationHistories.Clear();
            var lines = File.ReadAllLines(path);
            this.LoadKozakiBlockModelFile(lines);
            if (!this.blocks.Any()) this.LoadBlockModelFile(lines);
            if (!this.blocks.Any()) this.LoadColorBlockModelFile(lines);
            if (!this.blocks.Any()) this.LoadAssemblyPlanFile(lines);
            if (!this.blocks.Any()) return;
            this.activePosition = this.blocks.Max(block => block.script.Z);
            this.blockModelText.text = Path.GetFileName(path) + " (" + this.blocks.Count + ")";
        };
        FileBrowser.OnCancel onCancel = () => { };
        FileBrowser.SetFilters(false, new FileBrowser.Filter("Block Models", ".txt", ".block", ".csv"));
        FileBrowser.ShowLoadDialog(onSuccess, onCancel);
    }

    private void LoadKozakiBlockModelFile(IEnumerable<string> lines)
    {
        var lineRegex = new Regex(@"^(?<x>\d+) (?<y>\d+) (?<z>\d+) (?<size>\d\d)$");
        foreach (var line in lines)
        {
            var match = lineRegex.Match(line);
            if (!match.Success) continue;
            var x = int.Parse(match.Groups["x"].Value);
            var y = int.Parse(match.Groups["y"].Value);
            var z = int.Parse(match.Groups["z"].Value);
            var sizeX = int.Parse(match.Groups["size"].Value[0].ToString());
            var sizeY = int.Parse(match.Groups["size"].Value[1].ToString());
            var sizeZ = 1;
            this.CreateBlock(x, y, z, sizeX, sizeY, sizeZ, BlockColor.GetFromIndex(0));
        }
    }
    private void LoadBlockModelFile(IEnumerable<string> lines)
    {
        var lineRegex = new Regex(@"^(?<x>\d+) (?<y>\d+) (?<z>\d+) (?<sizeX>\d+) (?<sizeY>\d+) (?<sizeZ>\d+)$");
        foreach (var line in lines)
        {
            var match = lineRegex.Match(line);
            if (!match.Success) continue;
            var x = int.Parse(match.Groups["x"].Value);
            var y = int.Parse(match.Groups["y"].Value);
            var z = int.Parse(match.Groups["z"].Value);
            var sizeX = int.Parse(match.Groups["sizeX"].Value.ToString());
            var sizeY = int.Parse(match.Groups["sizeY"].Value.ToString());
            var sizeZ = int.Parse(match.Groups["sizeZ"].Value.ToString());
            this.CreateBlock(x, y, z, sizeX, sizeY, sizeZ, BlockColor.GetFromIndex(0));
        }
    }
    private void LoadColorBlockModelFile(IEnumerable<string> lines)
    {
        var lineRegex = new Regex(@"^(?<x>\d+) (?<y>\d+) (?<z>\d+) (?<sizeX>\d+) (?<sizeY>\d+) (?<sizeZ>\d+) (?<color>\d+)$");
        foreach (var line in lines)
        {
            var match = lineRegex.Match(line);
            if (!match.Success) continue;
            var x = int.Parse(match.Groups["x"].Value);
            var y = int.Parse(match.Groups["y"].Value);
            var z = int.Parse(match.Groups["z"].Value);
            var sizeX = int.Parse(match.Groups["sizeX"].Value.ToString());
            var sizeY = int.Parse(match.Groups["sizeY"].Value.ToString());
            var sizeZ = int.Parse(match.Groups["sizeZ"].Value.ToString());
            var color = int.Parse(match.Groups["color"].Value.ToString());
            this.CreateBlock(x, y, z, sizeX, sizeY, sizeZ, BlockColor.GetFromIndex(color));
        }
    }
    private void LoadAssemblyPlanFile(IEnumerable<string> lines)
    {
        var lineRegex = new Regex(@"^(?<area>\d+),(?<x>\d+),(?<y>\d+),(?<z>\d+),(?<sizeX>\d+),(?<sizeY>\d+),(?<sizeZ>\d+),(?<colorIndex>\d+),(?<isSupport>\d+),.*");
        foreach (var line in lines)
        {
            var match = lineRegex.Match(line);
            if (!match.Success) continue;
            var area = int.Parse(match.Groups["area"].Value);
            var x = int.Parse(match.Groups["x"].Value);
            var y = int.Parse(match.Groups["y"].Value);
            var z = int.Parse(match.Groups["z"].Value);
            var sizeX = int.Parse(match.Groups["sizeX"].Value.ToString());
            var sizeY = int.Parse(match.Groups["sizeY"].Value.ToString());
            var sizeZ = int.Parse(match.Groups["sizeZ"].Value.ToString());
            var color = int.Parse(match.Groups["colorIndex"].Value.ToString());
            var isSupport = int.Parse(match.Groups["isSupport"].Value.ToString()) == 1;
            var colorData = isSupport ? BlockColor.GetFromName("support") : BlockColor.GetFromIndex(color);
            this.CreateBlock(x + area * 30, y, z, sizeX, sizeY, sizeZ, colorData);
        }
    }

    public void WriteColoredKozakiBlockModelFile()
    {
        StringBuilder builder = new StringBuilder();
        var ordered = this.blocks
            .Where(b => !b.removed)
            .OrderBy(o => o.script.transform.position.z)
            .ThenBy(o => o.script.transform.position.x)
            .ThenBy(o => o.script.transform.position.y);
        foreach (var block in ordered)
        {
            var blockScript = block.script;
            builder.Append(blockScript.X);
            builder.Append(" ");
            builder.Append(blockScript.Y);
            builder.Append(" ");
            builder.Append(blockScript.Z);
            builder.Append(" ");
            builder.Append(blockScript.SizeX);
            builder.Append(" ");
            builder.Append(blockScript.SizeY);
            builder.Append(" ");
            builder.Append(blockScript.SizeZ);
            builder.Append(" ");
            builder.Append(blockScript.ColorIndex);
            builder.AppendLine();
        }
        FileBrowser.OnSuccess onSuccess = (path) =>
        {
            File.WriteAllText(path, builder.ToString());
        };
        FileBrowser.OnCancel onCancel = () => { };
        FileBrowser.ShowSaveDialog(onSuccess, onCancel);
    }

    private void CreateBlock(int x, int y, int z, int sizeX, int sizeY, int sizeZ, ColorData colorData)
    {
        var block = Instantiate(Resources.Load("block")) as GameObject;
        var blockScript = block.GetComponent<Block>();
        blockScript.SetPositionAndSize(x, y, z, sizeX, sizeY, sizeZ);
        blockScript.SetColor(colorData);
        var blockGameObject = new BlockGameObject()
        {
            gameObject = block,
            script = blockScript,
            bottomPosition = z,
            removed = false,
        };
        this.blocks.Add(blockGameObject);
    }
}
