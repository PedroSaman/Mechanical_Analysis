﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    private static readonly float blockUnitSizeX = 0.1f;
    private static readonly float blockUnitSizeY = blockUnitSizeX;
    private static readonly float blockUnitSizeZ = blockUnitSizeX * 3.0f / 4.0f;
    public int X { get; private set; }
    public int Y { get; private set; }
    public int Z { get; private set; }
    public int SizeX { get; private set; }
    public int SizeY { get; private set; }
    public int SizeZ { get; private set; }
    public int ColorIndex { get; private set; }
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
    }

    public void SetPositionAndSize(int x, int y, int z, int sizeX, int sizeY, int sizeZ)
    {
        if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0) throw new System.ArgumentException("size must be greater than 0");
        this.X = x;
        this.Y = y;
        this.Z = z;
        this.SizeX = sizeX;
        this.SizeY = sizeY;
        this.SizeZ = sizeZ;
        //unityはy軸が高さ方向なので注意
        var positionX = (x + (sizeX - 1) / 2.0f) * blockUnitSizeX;
        var positionY = (y + (sizeY - 1) / 2.0f) * blockUnitSizeY;
        var positionZ = (z + (sizeZ - 1) / 2.0f) * blockUnitSizeZ;
        var scaleX = sizeX * blockUnitSizeX * 0.99f;
        var scaleY = sizeY * blockUnitSizeY * 0.99f;
        var scaleZ = sizeZ * blockUnitSizeZ * 0.99f;
        this.transform.position = new Vector3(positionX, positionZ, positionY);
        this.transform.localScale = new Vector3(scaleX, scaleZ, scaleY);
    }
    public void SetColor(ColorData colorData)
    {
        this.ColorIndex = colorData.Index;
        this.GetComponent<Renderer>().material.color = colorData.Color;
    }
}
